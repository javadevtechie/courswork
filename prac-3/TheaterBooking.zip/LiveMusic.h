#ifndef LIVEMUSIC_H
#define LIVEMUSIC_H
#include "Event.h"
using namespace std;
class LiveMusic: public Event
{
    public:
        LiveMusic();

    protected:

    private:
};

#endif // LIVEMUSIC_H
