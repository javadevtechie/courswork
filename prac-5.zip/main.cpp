#include <iostream>
#include "TheaterBooking.h"
using namespace std;
int main()
{
    TheaterBooking t;
    t.mainMenu();
    return 0;
}



