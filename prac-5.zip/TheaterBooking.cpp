#include "TheaterBooking.h"
#include <string>
#include "Event.h"
#include <iostream>
#include <fstream>
#include "Film.h"
#include "StandupComedy.h"
#include "LiveMusic.h"
#include "Customer.h"
#include "TheaterUtility.h"
#include<bits/stdc++.h>
using namespace std;
TheaterBooking::TheaterBooking()
{
}

void TheaterBooking::subMenu()
{
    TheaterUtility tu;
    string eventStartDate,eventEndDate,eventName,seats;
    int ch=0;
    cout <<" 1. Film \n 2. StandUp Comedy \n 3. Live Music"<<endl;
    ch=tu.getInputForInt(ch,"Please enter the choice: ");
    switch(ch)
    {
    case 1:
    {
        eventName=tu.getInputForString(eventName,"Please enter Event Name: ");
        seats=tu.getInputForInt(ch,"Enter No.of seats: ");
        //cin >>seats;
        cout <<"Enter Event Start Date"<<endl;
        cin >>eventStartDate;
        cout <<"Enter Event EndDate"<<endl;
        cin >>eventEndDate;
        Film e1;
        e1.seteventName(eventName);
        e1.seteventId(rand());
        e1.seteventStartDate(eventStartDate);
        e1.seteventEndDate(eventEndDate);
        e1.settypeOfEvent("Film");
        e1.setnumberOfSeats(seats);
        e1.setfilmType("2D");
        addBooking(e1);
        break;
    }
    case 2:
    {
       eventName=tu.getInputForString(eventName,"Please enter Event Name: ");
        seats=tu.getInputForInt(ch,"Enter No.of seats: ");
        cout <<"Enter Event Start Date"<<endl;
        cin >>eventStartDate;
        cout <<"Enter Event EndDate"<<endl;
        cin >>eventEndDate;
        StandupComedy e1;
        e1.seteventName(eventName);
        e1.seteventId(rand());
        e1.seteventStartDate(eventStartDate);
        e1.seteventEndDate(eventEndDate);
        e1.settypeOfEvent("StandupComedy");
        e1.setnumberOfSeats( seats);
        addBooking(e1);
        break;
    }
    case 3:
    {

        eventName=tu.getInputForString(eventName,"Please enter Event Name: ");
        seats=tu.getInputForInt(ch,"Enter No.of seats: ");
        cout <<"Enter Event Start Date"<<endl;
        cin >>eventStartDate;
        cout <<"Enter Event EndDate"<<endl;
        cin >>eventEndDate;
        LiveMusic e1;
        e1.seteventName(eventName);
        e1.seteventId(rand());
        e1.seteventStartDate(eventStartDate);
        e1.seteventEndDate(eventEndDate);
        e1.settypeOfEvent("LiveMusic");
        e1.setnumberOfSeats( seats);
        addBooking(e1);
        break;
    }
    }
}



void TheaterBooking::menu()
{
    TheaterUtility tu;
    int ch;
    do
    {
        cout <<" 1. Add a booking for an event \n 2. Cancel/Refund a booking \n 3. List all events  \n 4. List details and availability of a given event \n  \n 6.Exit" <<endl;
        //cout << "Please enter the choice" <<endl;
        ch=tu.getInputForInt(ch,"Please enter the choice: ");
        switch(ch)
        {
        case 1:
            subMenu();
            break;
        case 2:
            break;
        case 3:
            listOfAllEvents();
            break;
        case 4:
            searchByEventName();
            break;
        }
    }
    while(ch!=6);
}
void TheaterBooking::addBooking(Event e)
{
    string record=std::to_string(e.geteventId())+"|"+e.geteventName()+"|"+e.geteventStartDate()+"|"+e.geteventEndDate()+"|"+ e.getnumberOfSeats()+"|"+e.gettypeOfEvent()+"\n";
    std::ofstream outfile;
    outfile.open("events.txt", std::ios_base::app);
    outfile << record;
}
void TheaterBooking::listOfAllEvents()
{
    string myText;
    ifstream MyReadFile("events.txt");
    while (getline (MyReadFile, myText))
    {
        cout << myText<<endl;
    }
    MyReadFile.close();

}
void TheaterBooking::searchByEventName()
{
    string eventName;
    cout<< "Enter Event Name"<<endl;
    cin>>eventName;
    string myText;
    ifstream MyReadFile("events.txt");
    while (getline (MyReadFile, myText))
    {
        if (myText.find(eventName) != std::string::npos)
        {
            std::cout << myText << '\n';
            break;
        }
    }
    MyReadFile.close();
}

void TheaterBooking::mainMenu()
{
    TheaterUtility tu;
    Customer c;
    cout<<"Welcome to Theater Booking system"<<endl;
    cout<<" 1. Staff \n 2. Customer "<<endl;
    int ch=0;
   // cin>>ch;
    ch=tu.getInputForInt(ch,"Please enter the choice: ");
    switch(ch)
    {
    case 1:
        menu();
        break;
    case 2:
        c.menu();
//        listOfAllEvents();
//        Customer c1;
//        c1.bookAnEvent();
        break;
    }
}
