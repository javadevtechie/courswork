#include "TheaterUtility.h"
#include<bits/stdc++.h>
#include <string>
#include <iostream>
#include "Customer.h"
TheaterUtility::TheaterUtility()
{

}

int TheaterUtility::getInputForInt(int choice, string message)
{
    cout<< message;
    cin>>  choice;
    while(!cin.good())
    {
        cout<<"ERROR: Faulty Input! try again .."<<"\n";
        cin.clear();
        cin.ignore(INT_MAX, '\n');
        cout<< message ;
        cin>> choice;
    }
    cin.clear();
    cin.ignore(INT_MAX, '\n');
    return choice;
}
string TheaterUtility::getInputForString(string input, string message)
{

    cout<< message;
    cin>>  input;
    while(!cin.good())
    {
        cout<<"ERROR: Faulty Input! try again .."<<"\n";
        cin.clear();
        cin.ignore(INT_MAX, '\n');
        cout<< "Enter input ";
        cin>> input;
    }
    cin.clear();
    cin.ignore(INT_MAX, '\n');
    return input;
}
string TheaterUtility::getInputForEventId(string eventId,string message)
{

    cout<< message;
    cin>>  eventId;
    while(!isValidEventId(eventId))
    {
        cout<<"ERROR: invalid eventId! try again .."<<"\n";
        cin.clear();
        cin.ignore(INT_MAX, '\n');
        cout<<"Enter Event Id: ";
        cin>> eventId;
    }
    cin.clear();
    cin.ignore(INT_MAX, '\n');
    return eventId;
}
bool TheaterUtility::isValidEventId(string eventId)
{
    TheaterUtility tu;
    string myText;
    ifstream MyReadFile("events.txt");
    while (getline (MyReadFile, myText))
    {
        vector<string> token=tu.getStringToken(myText);
        if (eventId.compare(token[0])==0)
        {

            MyReadFile.close();
            return true;
        }
    }
    MyReadFile.close();
    return false;
}
int TheaterUtility::getInputForSeats(string eventId,int seats,string message)
{
    TheaterUtility tu;
    seats=tu.getInputForInt(seats,message);
    while(!isSeatsValidForEventId(eventId,seats))
    {
        cout<<"ERROR: invalid seats are invalid or not available! try again .."<<"\n";
        cin>> seats;
        while(!cin.good())
        {
            cout<<"ERROR: invalid seats are invalid or not available! try again .."<<"\n";
            cin.clear();
            cin.ignore(INT_MAX, '\n');
            cin>> seats;
        }
        cin.clear();
        cin.ignore(INT_MAX, '\n');
        // seats=tu.getInputForInt(seats,"ERROR: invalid seats are invalid or not available! try again ..");
    }
    cin.clear();
    cin.ignore(INT_MAX, '\n');
    return seats;

}
bool TheaterUtility::isSeatsValidForEventId(string eventId,int seats)
{
    TheaterUtility tu;
    string myText;
    ifstream MyReadFile("events.txt");
    while (getline (MyReadFile, myText))
    {
        if (myText.find(eventId) != std::string::npos)
        {
            vector <string> tokens=tu.getStringToken(myText);
            int requiredSeats=seats;
            int availableSeats=std::stoi(tokens[4]);
            if(availableSeats>=requiredSeats)
            {
               // cout <<"seats ----"<<seats+std::stoi(tokens[4]);
                MyReadFile.close();
                 return true;

            }

        }

    }
    MyReadFile.close();
    return true;
}

vector<string> TheaterUtility::getStringToken(string myText)
{
    vector <string> tokens;
    stringstream check1(myText);

    string intermediate;
    while(getline(check1, intermediate, '|'))
    {
        tokens.push_back(intermediate);
    }

    return tokens;
}
vector<string> TheaterUtility::getEventById(string eventId){

  TheaterUtility tu;
    string myText;
    ifstream MyReadFile("events.txt");
    vector<string> token;
    while (getline (MyReadFile, myText))
    {
       token=tu.getStringToken(myText);
        if (eventId.compare(token[0])==0)
        {

            MyReadFile.close();
            return token;
        }
    }
    MyReadFile.close();
    return token;

}
