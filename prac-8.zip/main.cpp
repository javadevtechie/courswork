#include <iostream>
#include "TheaterBooking.h"
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iostream>
#include <fstream>
#include <string>
using namespace std;
int main()
{

    cout<<"Welcome to Theater Booking system"<<endl;
    TheaterBooking t;
    t.mainMenu();
    return 0;
}



