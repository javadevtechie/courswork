#include "LiveMusic.h"

LiveMusic::LiveMusic()
{
    //ctor
}

