#include "Event1.h"

Event1::Event1()
{
    //ctor
}
