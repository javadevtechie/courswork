
#include <string>
using namespace std;

class Event1
{
      private:
        int eventId;
        string eventName;
        string eventStartDate;
        string eventEndDate;
        string numberOfSeats;
    public:
        Event1();


        int geteventId() { return eventId; }
        void seteventId(int val) { eventId = val; }
        string geteventName() { return eventName; }
        void seteventName(string val) { eventName = val; }
        string geteventStartDate() { return eventStartDate; }
        void seteventStartDate(string val) { eventStartDate = val; }
        string geteventEndDate() { return eventEndDate; }
        void seteventEndDate(string val) { eventEndDate = val; }
        string getnumberOfSeats() { return numberOfSeats; }
        void setnumberOfSeats(string val) { numberOfSeats = val; }

    protected:


};
