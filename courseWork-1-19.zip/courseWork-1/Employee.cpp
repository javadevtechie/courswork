#include "Employee.h"

Employee::Employee()
{
    //ctor
}

