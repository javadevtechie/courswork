#ifndef PERSON_H
#define PERSON_H

#include <string>
#include "Person.h"
using namespace std;
class Person
{
    private:
        string name;

    public:
        Person();
        string getname() { return name; }
        void setname(string val) { name = val; }

};

#endif // PERSON_H
