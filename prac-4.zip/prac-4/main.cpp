#include <iostream>
#include "Event.h"
#include "Film.h"
#include "StandupComedy.h"
#include <string>

#include "TheaterBooking.h"
using namespace std;

int main()
{

 TheaterBooking t;
    t.mainMenu();

}



