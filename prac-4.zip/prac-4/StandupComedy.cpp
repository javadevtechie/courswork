#include "StandupComedy.h"

StandupComedy::StandupComedy()
{
    //ctor
}


