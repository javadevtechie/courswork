#ifndef TESTCLASS_H
#define TESTCLASS_H


class TestClass
{
    public:
        TestClass();
        virtual ~TestClass();

    protected:

    private:
};

#endif // TESTCLASS_H
