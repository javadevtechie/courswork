#include "TheaterBooking.h"

#include <string>
#include "Event.h"
#include <iostream>

#include <fstream>
using namespace std;
TheaterBooking::TheaterBooking()
{
    //ctor
}

void TheaterBooking::addBooking(Event e)
{
//    ofstream file("events.txt");
    string record=std::to_string(e.geteventId())+"|"+e.geteventName()+"|"+e.geteventStartDate()+"|"+e.geteventEndDate()+"|"+ e.getnumberOfSeats()+"|"+e.gettypeOfEvent()+"\n";
//    cout << record <<endl;
//    file << record;
//    file.close();



    std::ofstream outfile;

    outfile.open("events.txt", std::ios_base::app); // append instead of overwrite
    outfile << record;


}
void TheaterBooking::listOfAllEvents()
{
    string myText;
    ifstream MyReadFile("events.txt");
    while (getline (MyReadFile, myText))
    {
        cout << myText;
    }
    MyReadFile.close();

}
