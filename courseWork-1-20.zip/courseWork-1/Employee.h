#ifndef EMPLOYEE_H
#define EMPLOYEE_H
#include <string>
#include "Person.h"
using namespace std;

class Employee : public Person
{

    private:
        string id;


    public:
        Employee();
        string Getid() { return id; }
        void Setid(string val) { id = val; }


};

#endif // EMPLOYEE_H
